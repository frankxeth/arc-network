// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

contract HelloArchitect {
    string private greeting;
    event GreetingChanged(string newGreeting);

    constructor() { greeting = "Hello Architect!"; }

    function setGreeting(string memory newGreeting) public {
        greeting = newGreeting;
        emit GreetingChanged(newGreeting);
    }

    function getGreeting() public view returns (string memory) {
        return greeting;
    }
}
